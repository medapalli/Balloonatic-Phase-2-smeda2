const { DataStore } = require('notarealdb');

const store = new DataStore('./data');

module.exports={
    products :store.collection('products'),
    users :store.collection('users')
}