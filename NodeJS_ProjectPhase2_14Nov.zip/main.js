const express = require('express');
const http = require('http');
const bcrypt = require('bcrypt');
const path = require("path");
const bodyParser = require('body-parser');
const users = require('./data').userDB;

const cookieParser = require("cookie-parser");
const sessions = require('express-session');

const app = express();
const server = http.createServer(app);

app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname,'./public')));

app.use(cookieParser());

var session;

const oneDay = 1000 * 60 * 60 * 24;
app.use(sessions({
    secret: "thisismysecrctekeyfhrgfgrfrty84fwir767",
    saveUninitialized:true,
    cookie: { maxAge: oneDay },
    resave: false 
}));

app.set('view engine', 'ejs');

app.get("/", (req, res) => {
    session=req.session;
    
  res.render("home",{isauthenticated:session.isauthenticated});
});

app.get("/about", (req, res) => {
    session=req.session;
  res.render("about",{isauthenticated:session.isauthenticated});
});

app.get("/contact", (req, res) => {
    session=req.session;
  res.render("contact",{isauthenticated:session.isauthenticated});
});

app.get("/product", (req, res) => {
    session=req.session;
    var products = require("./data/products.json");
  
  res.render("product", {isauthenticated:session.isauthenticated,

      products: products
  });
});

app.get("/login", (req, res) => {
  res.render("login");
});

app.get("/logout", (req, res) => {
    session=req.session;
    session.email="";
    session.isauthenticated=0;
    res.send(`<div align ='center'><h2>You have successfully logged out <br> <br> Thank You for Visiting us</h2></div><br><br><br><div align='center'><a href='/'>Return to HomePage</a></div>`);
    //res.redirect("/");
  });

  

app.get("/register", (req, res) => {

  res.render("register");
});



app.post('/register', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.email === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.password, 10);
    
            let newUser = {
                id: Date.now(),
                
                email: req.body.email,
                password: hashPassword,
                firstname: req.body.firstname,
                lastname: req.body.lastname,
                
                city: req.body. city,
                state: req.body.state,
                zip: req.body.zip,
                phone: req.body.phone,
                
            };


            users.push(newUser);
            console.log('User list', users);
    
            //res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login'>login</a></div><br><br><div align='center'><a href='./register'>Register another user</a></div>");
            
            res.redirect('/');
        } 

       
        else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./register'>Register again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});

app.post('/login', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.email === data.email);
        if (foundUser) {
    
            let submittedPass = req.body.password; 
            let storedPass = foundUser.password; 

            console.log(submittedPass);
            console.log(storedPass);

    
            const passwordMatch = await bcrypt.compare(submittedPass, storedPass);
            if (passwordMatch) {
                session=req.session;
                session.email=req.body.email;
                session.isauthenticated=1;
                console.log(req.session)
                let fname = foundUser.firstname;
                //res.send(`<div align ='center'><h2>login successful</h2></div><br><br><br><div align ='center'><h3>Hello ${fname}</h3></div><br><br><div align='center'><a href='./login'>logout</a></div>`);
               
                res.redirect('/');
            } else {
                res.send("<div align ='center'><h2>Invalid email or password</h2></div><br><br><div align ='center'><a href='./login'>login again</a></div>");
            }
        }
        else {
    
            let fakePass = `$2b$$10$ifgfgfgfgfgfgfggfgfgfggggfgfgfga`;
            await bcrypt.compare(req.body.password, fakePass);
    
            res.send("<div align ='center'><h2>Invalid email or password</h2></div><br><br><div align='center'><a href='./login'>login again<a><div>");
        }
    } catch (err){
        console.log(err.stack);
        res.send("<div align ='center'><h2>Internal Server Error</h2></div><br><br><div align ='center'><a href='./'>Go to Home Page</a></div>");
    }
});


server.listen(3000, function(){
    console.log("server is listening on port: 3000");
});